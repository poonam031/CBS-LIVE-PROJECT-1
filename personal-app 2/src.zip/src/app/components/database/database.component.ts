import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-database',
  standalone: true,
  templateUrl: './database.component.html',
  styleUrls: ['./database.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class DatabaseComponent implements OnInit {
  databases = [
    { name: 'MySQL', img: 'assets/images/mysql.png' },
    { name: 'MsSQL', img: 'assets/images/mssql.png' },
    { name: 'PostgreSQL', img: 'assets/images/postgres.png' },
    { name: 'MariaDB', img: 'assets/images/mariadb2(2).png' },
    { name: 'MongoDB', img: 'assets/images/mongodb.png' },
    { name: 'Oracle', img: 'assets/images/oracle.png' },
  ];

  selectedPrimary: string | null = null;
  selectedClient: string | null = null;

  primaryClassMap: { [key: string]: string } = {};
  clientClassMap: { [key: string]: string } = {};

  primaryDatabaseName: string = '';
  clientDatabaseName: string = '';

  databaseForm!: FormGroup;

  constructor(private router: Router, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.databaseForm = this.fb.group({
      type: [''],
      username: [''],
      // ✅ Added password validation
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).+$/)
        ]
      ],
      port: [''],
      host: [''],
      database: ['']
    });
  }

  // ===== Select Primary Database =====
  selectPrimary(dbName: string) {
    this.selectedPrimary = dbName;
    this.primaryClassMap = {};
    this.primaryClassMap[dbName] = 'ring-4 ring-green-400';
    this.primaryDatabaseName = dbName;
  }

  // ===== Select Client Database =====
  selectClient(dbName: string) {
    this.selectedClient = dbName;
    this.clientClassMap = {};
    this.clientClassMap[dbName] = 'ring-4 ring-green-400';
    this.clientDatabaseName = dbName;

    this.databaseForm.patchValue({
      database: dbName
    });
  }

  // ===== OK Button =====
  onOkClick() {
    if (this.databaseForm.invalid) {

      this.databaseForm.markAllAsTouched();


      if (this.databaseForm.get('password')?.invalid) {
        alert(
          'Invalid password.\nPassword must be at least 8 characters and include uppercase, lowercase, number, and special character.'
        );
      } else {
        alert('Please fill out the form correctly.');
      }
      return;
    }

    if (!this.selectedPrimary || !this.selectedClient) {
      alert('Please select both Primary and Client databases.');
      return;
    }

    console.log('Form Data:', this.databaseForm.value);

    this.router.navigate(['/table'], {
      queryParams: {
        primary: this.selectedPrimary,
        client: this.selectedClient
      }
    });
  }

  // ===== Cancel Button =====
  onCancelClick() {
    this.databaseForm.reset();

    this.selectedPrimary = null;
    this.primaryClassMap = {};
    this.primaryDatabaseName = '';

    this.selectedClient = null;
    this.clientClassMap = {};
    this.clientDatabaseName = '';
  }
}
