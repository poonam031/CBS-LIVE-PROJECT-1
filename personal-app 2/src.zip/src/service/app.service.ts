import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  http = inject(HttpClient)
  BASE_URL = 'http://localhost:3000/'

  constructor() { }


  getAllTableNames() {
    return this.http.get(this.BASE_URL + 'migrate/getAllTableName')
  }
  getAllColumnsNames(tableName: string) {
    return this.http.post(this.BASE_URL + 'migrate/getAllColumnsNames', { tableName });
  }

}
