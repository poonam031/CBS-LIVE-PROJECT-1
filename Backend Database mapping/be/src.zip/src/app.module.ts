import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MigrationModule } from './migration/migration.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { config } from './orm.config'
import { IDMASTER } from './entity/customer-id.entity';
import { DAILYTRAN } from './entity/voucher.entity';
import { DEPOTRAN } from './entity/depotran.entity';
import { LOANTRAN } from './entity/loantran.entity';
import { PIGMYTRAN } from './entity/pigmytran.entity';
import { SCHEMAST } from './entity/schemeParameters.entity';
import { SHARETRAN } from './entity/sharetran.entity';
import { SYSPARA } from './entity/system-master-parameters.entity';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [MigrationModule ,
    ConfigModule.forRoot({ isGlobal : true , envFilePath : '.env'}),
    TypeOrmModule.forRoot(config),TypeOrmModule.forFeature([IDMASTER,DAILYTRAN,DEPOTRAN,LOANTRAN,PIGMYTRAN,SCHEMAST,SHARETRAN,SYSPARA]),
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
