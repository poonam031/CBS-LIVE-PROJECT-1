import { TypeOrmModuleOptions } from '@nestjs/typeorm';
export const config: TypeOrmModuleOptions = {
  // type :'postgres',
  // username: 'dbuser', //sidhanerli username
  // password: 'dbuser@compserv', //sidhanerli password
  //   port: 5432,
  // host: '82.112.235.98',
  // database : 'NIRMITIDHARASHIV',

  // database : 'GSGADMAD',
  // database : 'GSVIJTANTRIK',
  // database : 'GSTKOP',
  // database : 'ASHOKRAOMANE',
  type: 'postgres',
  username: 'postgres', //sidhanerli username
  password: '123456', //sidhanerli password
  port: 5432,
  host: '192.168.1.131',
  // database : 'GADMADHYAMIK',
  // database : 'ASHOKRAOMANE',
  // database : 'GSGADMAD',
  database: 'TESTCOMPSERV',
  synchronize: false,
  // synchronize: true,
  logging: false,
  // logging: true,
  entities: ['dist/**/*.entity{.ts,.js}'],
  migrations: ["dist/migration/*{.ts,.js}"],
  //   cli: {
  //     migrationsDir: 'src/migration'
  //   },
};
